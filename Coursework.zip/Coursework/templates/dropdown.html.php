<select name="authors"><option value="">Select an author</option>
    <option value="Phong">Phong</option>
    <option value="Tin">Tin</option>
    <option value="Duc">Duc</option>
</select>