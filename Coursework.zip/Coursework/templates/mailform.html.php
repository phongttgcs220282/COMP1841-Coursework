<form action="" method="post">
<label for="message">Your Message:</label>
<textarea name="message" rows="15" cols="40"></textarea>
<input type="submit" value="send email">
</form>