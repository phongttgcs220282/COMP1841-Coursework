<?php setcookie( "user", "matt", time()+3600); ?>
<html>
<head>